# Backend Runtime Secrets 2026-04-22

敏感说明：本文件包含当前工程允许在后端环境中设置的密钥、会话和登录态信息，应视为敏感记录文件。

## Exa
- `QIANDU_EXA_API_KEY`
- `EXA_API_KEY`
- 当前值：`b2d01009-c20d-413e-915a-07b4b906ae01`

## Qiandu 登录态
- `QIANDU_CRAWL4AI_COOKIES_JSON`
- `QIANDU_CRAWL4AI_HEADERS_JSON`
- `QIANDU_CRAWL4AI_PROFILE_DIR`
- 当前 profile 目录：`/app/.crawl4ai/profiles/qiandu`

## Telegram 会话
- `TELEGRAM_BRIDGE_SESSION_STRING`
- `TELEGRAM_BRIDGE_API_ID`
- `TELEGRAM_BRIDGE_API_HASH`
- `TELEGRAM_BRIDGE_TARGET_BOT_USERNAME`
- `TELEGRAM_BRIDGE_REQUIRED_PEERS`

## 运行约定
- 所有 key、session id、cookies、headers 都允许后端 `.env` 直接设置
- 相关阶段如果配置错误、请求失败或浏览器登录态异常，应跳过该阶段，不阻塞整条链路
- `#千度` 当前已按该原则实现：
  - provider 异常可跳过
  - extractor 异常可跳过
  - LLM 总结异常会回退到证据摘要

## Exa 参考
- Canonical reference: [https://docs.exa.ai/reference/search-api-guide-for-coding-agents](https://docs.exa.ai/reference/search-api-guide-for-coding-agents)
- 当前接入按官方参数落地：
  - `POST https://api.exa.ai/search`
  - `x-api-key`
  - `type="auto"`
  - `contents.highlights.maxCharacters`

## Telegram Audit Gemini
- `TELEGRAM_AUDIT_NODE_CODE`
- `TELEGRAM_AUDIT_PROVIDER_CODE`
- `TELEGRAM_AUDIT_GEMINI_BASE_URL`
- `TELEGRAM_AUDIT_GEMINI_API_KEY`
- `TELEGRAM_AUDIT_GEMINI_MODEL`
- `TELEGRAM_AUDIT_GEMINI_FALLBACK_MODELS`
- Current values:
  - `TELEGRAM_AUDIT_NODE_CODE=telegram-audit-gemini`
  - `TELEGRAM_AUDIT_PROVIDER_CODE=google-gemini`
  - `TELEGRAM_AUDIT_GEMINI_BASE_URL=https://generativelanguage.googleapis.com/v1beta/openai`
  - `TELEGRAM_AUDIT_GEMINI_API_KEY=AIzaSyCtIQ8TcC--N2hb6qoOvLWbWTvGfmD_238`
  - `TELEGRAM_AUDIT_GEMINI_MODEL=gemini-2.5-flash`
  - `TELEGRAM_AUDIT_GEMINI_FALLBACK_MODELS=gemini-2.5-pro,gemini-pro-latest`
