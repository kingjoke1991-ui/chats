"""Chat Oracle application package."""
